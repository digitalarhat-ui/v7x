(function(){"use strict";
const reduce=matchMedia("(prefers-reduced-motion: reduce)");
const scrollLine=document.createElement("div");scrollLine.className="p6-top-line";scrollLine.setAttribute("aria-hidden","true");document.body.append(scrollLine);
let tick=false;function progress(){tick=false;const root=document.documentElement;const total=Math.max(0,root.scrollHeight-innerHeight);const pct=total>0?Math.max(0,Math.min(100,scrollY/total*100)):0;scrollLine.style.width=pct.toFixed(2)+"%"}
addEventListener("scroll",()=>{if(!tick){tick=true;requestAnimationFrame(progress)}},{passive:true});addEventListener("resize",progress,{passive:true});progress();
let observer;
if("IntersectionObserver" in window&&!reduce.matches){
 observer=new IntersectionObserver(entries=>{for(const item of entries){if(!item.isIntersecting)continue;const e=item.target;observer.unobserve(e);if(e.dataset.p6Done)return;e.dataset.p6Done="1";
 if(e.closest(".stage:not(.active)"))continue;
 const delay=Math.min(100,Number(e.dataset.p6Delay)||0);
 try{e.animate([{opacity:.62,transform:"translate3d(0,15px,0)"},{opacity:1,transform:"translate3d(0,0,0)"}],{duration:620,delay,easing:"cubic-bezier(.22,1,.36,1)",fill:"none"})}catch{}
 }},{rootMargin:"0px 0px -7% 0px",threshold:.08});
}
let pending=false;
function register(){
 pending=false;if(!observer||reduce.matches)return;
 const targets=[".bariqRealWork h2",".p5-copy h2",".p5-example",".phaseProgress",".stage.active .stageHead",".stage.active .paper",".stage.active .p5-readiness",".stage.active .p5-handoff"];
 for(const selector of targets){document.querySelectorAll(selector).forEach((el,i)=>{if(el.dataset.p6Observed)return;el.dataset.p6Observed="1";el.dataset.p6Delay=String(Math.min(i*35,105));observer.observe(el)})}
}
function schedule(){if(!pending){pending=true;requestAnimationFrame(register)}}
const main=document.querySelector("main")||document.body;
if(observer){
 register();
 const mo=new MutationObserver(records=>{if(records.some(r=>r.type==="attributes"&&r.target.classList?.contains("stage")||r.type==="childList"&&r.addedNodes.length))schedule()});
 mo.observe(main,{subtree:true,childList:true,attributes:true,attributeFilter:["class"]});
 reduce.addEventListener?.("change",e=>{if(e.matches){observer.disconnect();document.documentElement.classList.add("p6-motion-fallback")}else{document.documentElement.classList.remove("p6-motion-fallback");register()}});
}
document.addEventListener("pointerdown",e=>{if(reduce.matches||e.pointerType==="touch")return;const btn=e.target.closest?.(".btnPrimary,.nextBtn,.p5-buttons button,.p5-copy a");if(!btn)return;btn.classList.add("p6-pressed");const off=()=>btn.classList.remove("p6-pressed");btn.addEventListener("pointerup",off,{once:true});btn.addEventListener("pointercancel",off,{once:true})},{passive:true});
})();
