(function(){"use strict";
function showHint(){const panel=document.querySelector("section.stage.active #measurementPanel");if(!panel||!panel.querySelector("#roomLength")||panel.querySelector(".p4-dim-explanation"))return;const note=document.createElement("p");note.className="p4-dim-explanation";note.innerHTML='الأرقام غير مُدخلة مسبقاً. <strong>اكتب قياساتك التقريبية بنفسك</strong> بالسنتمتر، أو اختر «غير متأكد» للمتابعة بدون قياسات.';panel.prepend(note)}
function inputError(){document.querySelector("#p4-dim-error")?.remove();document.querySelectorAll("#roomLength,#roomWidth").forEach(x=>x.removeAttribute("aria-invalid"))}
document.addEventListener("click",e=>{const target=e.target;if(!(target instanceof Element))return;
if(target.closest("#nextBtn")&&document.querySelector("section.stage.active")?.dataset.stage==="1"){
 const a=document.querySelector("#roomLength"),b=document.querySelector("#roomWidth");if(!a||!b)return;const av=a.value.trim(),bv=b.value.trim();
 if(av&&bv&&Number(av)>=200&&Number(av)<=1200&&Number(bv)>=180&&Number(bv)<=1000)return;
 e.preventDefault();e.stopImmediatePropagation();let msg=document.querySelector("#p4-dim-error");if(!msg){msg=document.createElement("div");msg.id="p4-dim-error";msg.className="p4-dim-error";msg.setAttribute("role","alert");document.querySelector("#measurementPanel")?.append(msg)}
 msg.textContent="أدخل الطول والعرض التقريبيين بنفسك، أو اختر «غير متأكد / أحتاج قياساً» للمتابعة دون قياسات.";
 const invalidA=!av||Number(av)<200||Number(av)>1200,invalidB=!bv||Number(bv)<180||Number(bv)>1000;
 if(invalidA)a.setAttribute("aria-invalid","true");if(invalidB)b.setAttribute("aria-invalid","true");(invalidA?a:b).focus({preventScroll:true});msg.scrollIntoView({behavior:"smooth",block:"nearest"});
}else setTimeout(showHint,85)
},true);
document.addEventListener("input",e=>{if(["roomLength","roomWidth"].includes(e.target?.id))inputError()},true);
window.addEventListener("hashchange",()=>setTimeout(showHint,100));
if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",showHint,{once:true});else showHint();
})();