(function(){"use strict";
const phase=[["المساحة والتخطيط","خطوة البداية","اختر ما تعرفه فقط. القياسات ليست إلزامية؛ يمكن لفريق التصميم تأكيدها لاحقاً."],["التصور ثلاثي الأبعاد","اتجاه بصري","يمكنك تجربة التوزيع والألوان والعودة للتعديل قبل مشاركة الملخص."],["الاحتياجات والاستخدام","أولوياتك","حدد الأجهزة والتخزين المهمين فعلاً. يمكن ترك الخيارات غير المعروفة بدون اختيار."],["مراجعة المشروع","مراجعة صريحة","راجع ما اخترته وما يزال بحاجة إلى قياس أو موافقة المصمم."],["ملخص للمصمم","نسخ ومشاركة","تقدمك محفوظ على جهازك؛ انسخ الملخص وشاركه بنفسك. لا يتم إرسال شيء تلقائياً."]];
let pending=false;
function stored(){try{return JSON.parse(localStorage.getItem("da:kitchen:absher-tabuk:v2:project")||"null")}catch{return null}}
function update(){
pending=false;const active=document.querySelector("section.stage.active");if(!active)return;
const num=Math.max(1,Math.min(5,Number(active.dataset.stage)||1)),info=phase[num-1];
if(!active.querySelector(".p4-guidance")){let bar=document.createElement("div");bar.className="p4-guidance";bar.setAttribute("role","note");bar.innerHTML='<span class="p4-stage-pill">الخطوة <b>'+String(num).padStart(2,"0")+'</b> من 05 · '+info[1]+'</span><p>'+info[2]+'</p>';const header=active.querySelector(".stageHead");header?header.after(bar):active.prepend(bar)}
let save=document.querySelector("#p4-save-status");if(!save){save=document.createElement("div");save.id="p4-save-status";save.className="p4-save-status";save.setAttribute("role","status");const nav=document.querySelector(".bottomNav");nav?nav.before(save):document.querySelector("main")?.after(save)}
if(save){const h='<span><i aria-hidden="true">●</i> '+(stored()?"محفوظ على هذا الجهاز":"سيُحفظ تقدمك على جهازك")+'</span><span class="p4-save-sub">'+(num===5?"جاهز للنسخ والمراجعة":"يمكنك الرجوع والتعديل دون بدء من جديد")+'</span>';if(save.innerHTML!==h)save.innerHTML=h}
const meas=active.querySelector("#measurementPanel");
if(meas&&document.querySelector('[data-measuremode="known"].active')&&!meas.querySelector(".p4-dim-explanation")){const msg=document.createElement("p");msg.className="p4-dim-explanation";msg.innerHTML='الأرقام التالية <strong>ليست قياسات افتراضية</strong>. اكتب الطول والعرض التقريبيين بالسنتمتر، أو اختر «غير متأكد». ';meas.prepend(msg)}
for(const [id,arabic] of [["roomLength","الطول التقريبي بالسنتيمتر"],["roomWidth","العرض التقريبي بالسنتيمتر"]]){let el=document.getElementById(id);if(el){el.setAttribute("autocomplete","off");el.setAttribute("aria-label",arabic)}}
document.querySelectorAll(".phaseProgress li").forEach((li,i)=>{const b=li.querySelector("button");if(!b)return;if(i+1===num)b.setAttribute("aria-current","step");else b.removeAttribute("aria-current");b.setAttribute("aria-label","الخطوة "+(i+1)+" "+phase[i][0])})
}
function queue(){if(!pending){pending=true;requestAnimationFrame(update)}}
function begin(){
const root=document.querySelector("main")||document.body;
const mo=new MutationObserver(changes=>{for(const rec of changes){if(rec.target instanceof HTMLElement&&rec.target.closest("#p4-save-status,.p4-guidance,.p4-dim-explanation,#p4-dim-error"))continue;if(rec.type==="attributes"&&rec.target.classList?.contains("stage")){queue();break}if(rec.type==="childList"&&[...rec.addedNodes].some(n=>n.nodeType===1&&!(n instanceof HTMLElement&&(/(^|\s)p4-/.test(String(n.className||""))||n.id==="p4-save-status")))){queue();break}}});
mo.observe(root,{subtree:true,childList:true,attributes:true,attributeFilter:["class"]});
document.addEventListener("click",e=>{
const next=e.target.closest?.("#nextBtn");if(!next||document.querySelector("section.stage.active")?.dataset.stage!=="1"||!document.querySelector('[data-measuremode="known"].active'))return;
const len=document.querySelector("#roomLength"),wid=document.querySelector("#roomWidth");if(!len||!wid)return;
const l=len.value.trim(),w=wid.value.trim();if(l&&w&&Number(l)>=200&&Number(l)<=1200&&Number(w)>=180&&Number(w)<=1000)return;
e.preventDefault();e.stopImmediatePropagation();
let msg=document.querySelector("#p4-dim-error");if(!msg){msg=document.createElement("div");msg.id="p4-dim-error";msg.className="p4-dim-error";msg.setAttribute("role","alert");document.querySelector("#measurementPanel")?.append(msg)}
msg.textContent="أدخل الطول والعرض التقريبيين بنفسك ضمن الحدود الموضحة، أو اختر «غير متأكد / أحتاج قياساً» للمتابعة دون قياسات.";
if(!l||Number(l)<200||Number(l)>1200)len.setAttribute("aria-invalid","true");if(!w||Number(w)<180||Number(w)>1000)wid.setAttribute("aria-invalid","true");
((!l||Number(l)<200||Number(l)>1200)?len:wid).focus({preventScroll:true});
msg.scrollIntoView({behavior:"smooth",block:"nearest"});
},true);
document.addEventListener("input",e=>{if(["roomLength","roomWidth"].includes(e.target.id)){e.target.removeAttribute("aria-invalid");document.querySelector("#p4-dim-error")?.remove()}if(["roomLength","roomWidth","city","projectNote","customerName"].includes(e.target.id))setTimeout(queue,70)},true);
document.addEventListener("click",()=>setTimeout(queue,105),true);window.addEventListener("hashchange",()=>setTimeout(queue,105));update();
}
if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",begin,{once:true});else begin();
})();