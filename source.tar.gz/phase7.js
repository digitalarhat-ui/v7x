(function(){"use strict";
function patch(){
const h=document.getElementById("heroWrap");if(h&&h.getAttribute("role")==="button"){h.setAttribute("role","group");h.setAttribute("aria-label","مطبخ ثلاثي الأبعاد: اسحب للتدوير، أو اضغط Enter لفتح الاستوديو");}
const elements=[["waPreview","معاينة ملخص المشروع القابلة للتمرير"],["p5-brief","موجز المصمم القابل للتمرير"]];
for(const pair of elements){const el=document.getElementById(pair[0]);if(el){el.setAttribute("tabindex","0");el.setAttribute("role","region");el.setAttribute("aria-label",pair[1])}}
}
if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",patch,{once:true});else patch();
document.addEventListener("click",()=>setTimeout(patch,85),true);
window.addEventListener("hashchange",()=>setTimeout(patch,85));
})();
